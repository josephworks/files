package myservermod;

import com.youthdigital.servermod.game.*;

public class Game extends TeamData {
  public Game(ChatColors teamColor, String teamNameDisplay) {
    super("emeraldtnt, Nick_team, Matthew_1000", teamColor, teamNameDisplay);
  }
  
  public static void setupGameRules() {
    
    GameInfo.setServerDescription("techblock");
    GameInfo.addToWhitelist("emeraldtnt, Nick_team, Matthew_1000, ydMichael");
    GameInfo.addToOPs("emeraldtnt, Nick_team, Matthew_1000, ydMichael");
     
   //game rules
   GameInfo.disableBlockBreaking();
   GameInfo.disableMobSpawning();
   GameInfo.setTime(6000);
   GameInfo.setDifficulty(1);
   GameInfo.isRaining(false);
   GameInfo.setPVP(false);
  }
                                        
  @Override
  public void onUpdate() {                                  
    /*healing blocks*/
    if (Conditions.isStandingOnBlock("heal") && Conditions.secondsGoneBy(2)) {
    Actions.restoreHealth(1);
    Actions.restoreHunger(1);
    }                                   /*remember to leave a comma after each statement*/
	/* MOB SPAWNING */    
		     
		// zombie
     if (Conditions.secondsGoneBy(15)) {
       Actions.spawnSpecialEntityInRange("zombieSpawn", 5, EntityZombie.class, 1,
                                         Items.stone_pickaxe, Enchantment.knockback, 3,
                                         Items.chainmail_boots, 
                                         Items.chainmail_chestplate,
                                         Items.golden_leggings,
                                         Items.chainmail_helmet,                                 
                                         Potion.fireResistance, 10000,
                                         SharedMonsterAttributes.maxHealth, 10,
                                         SharedMonsterAttributes.movementSpeed, 0.3);
     }
		     
     // skeleton
     if (Conditions.secondsGoneBy(15)) {
       Actions.spawnSpecialEntityInRange("skeletonSpawn", 10, EntitySkeleton.class, 1,
                                         Items.bow, Enchantment.punch, 1,                                       
                                         Items.leather_helmet, 
                                         SharedMonsterAttributes.maxHealth, 5);
     }
		     
     // blaze
     if (Conditions.secondsGoneBy(15)) {
       Actions.spawnSpecialEntityInRange("blazeSpawn", 10, EntityBlaze.class, 1,
                                         SharedMonsterAttributes.maxHealth, 10 );
     }
  
		/* CHESTS */
     Random random = new Random();
     int fillRate = random.nextInt(5) + 11;  

     String[] chestArray = { "chest1", "chest2", "chest3", "chest4" };
     Item[] itemArray = { Items.golden_apple, Items.stone_sword, Items.diamond_pickaxe, Items.milk_bucket, Items.iron_helmet };

     int chestNumber = random.nextInt(chestArray.length);
     int itemNumber = random.nextInt(itemArray.length);

     if(Conditions.secondsGoneBy(fillRate) && Conditions.getChestCount(chestArray[chestNumber]) > 3) {
       Actions.fillChest(chestArray[chestNumber], itemArray[itemNumber], 5);   }
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onStartGame() {
    
  }
}