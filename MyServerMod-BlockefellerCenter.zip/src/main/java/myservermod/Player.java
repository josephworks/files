package myservermod;

import com.youthdigital.servermod.game.*;

public class Player extends PlayerData {
  
  public Player(EntityPlayer parPlayerObject) {
    super(parPlayerObject);
  }
  
  @Override
  public void onUpdate() {
    /*teleportation blocks*/
    if(Conditions.didRightClickBlock("redTeamJoin")) {
      Actions.teleportPlayers("redTeamBase"); }
    
    if(Conditions.didRightClickBlock("adminSend")) {
      Actions.teleportPlayers("adminAccess"); }
      
    if(Conditions.didRightClickBlock("blueTeamJoin")) {
      Actions.teleportPlayers("blueTeamBase"); }
    
    if(Conditions.didRightClickBlock("shopStart")) {
      Actions.teleportPlayers("shop"); }
    
    		//healing block
		if (Conditions.isStandingOnBlock("health") && Conditions.secondsGoneBy(1)) {
			Actions.restoreHealth(1);
        Actions.restoreHunger(1); }

    }
    

  @Override
  public void onJoinedServer(){
    Actions.teleportPlayers("lobbySpawn");
  }
  
  @Override
  public void onStartGame() {
    
  }
  
  @Override
  public void onResetGameToLobby() {

  }
  
  @Override
  public void onRespawned() {
    Actions.teleportPlayers("lobbySpawn");
    
  }
  
  
}